// Bizora Website JavaScript - Versão Corrigida
// Otimizado para performance, acessibilidade e conversão

(function() {
    'use strict';

    // Configurações globais
    const CONFIG = {
        whatsappNumber: '258863181415',
        email: 'vijaronaa@gmail.com',
        siteUrl: 'https://bizora.neocities.org/',
        carouselAutoplayDelay: 5000,
        scrollOffset: 80
    };

    // Dados dos produtos para modal
    const PRODUCTS_DATA = {
        'tapete-massageador': {
            name: 'Tapete Massageador Profissional',
            price: '2.999 MT',
            originalPrice: '3.500 MT',
            discount: '14%',
            images: ['products/tapete-massageador.webp'],
            description: 'Alivie o stress e a dor nos pés com o nosso tapete massageador de alta tecnologia. Ideal para relaxamento diário e melhoria da circulação sanguínea.',
            features: [
                'Tecnologia de acupressão avançada com 1.500 pontos de pressão',
                'Material antiderrapante e durável',
                'Fácil de limpar e manter',
                'Design ergonómico para máximo conforto',
                'Estimula pontos de reflexologia dos pés'
            ],
            benefits: [
                'Reduz significativamente o stress e tensão',
                'Melhora a circulação sanguínea nos pés e pernas',
                'Alivia dores nos pés, tornozelos e panturrilhas',
                'Promove relaxamento profundo e bem-estar'
            ],
            specifications: {
                'Dimensões': '35cm x 35cm',
                'Material': 'Plástico ABS de alta qualidade',
                'Peso': '800g',
                'Garantia': '30 dias'
            },
            testimonials: [
                {
                    text: "Uso todos os dias após o trabalho. Sinto uma diferença incrível na circulação dos meus pés!",
                    author: "Maria S., Maputo"
                }
            ],
            urgency: 'Apenas 8 unidades restantes!',
            badge: 'Mais Vendido'
        },
        'cinta-modeladora': {
            name: 'Cinta Modeladora Feminina Premium',
            price: '1.299 MT',
            originalPrice: '1.599 MT',
            discount: '19%',
            images: ['products/cinta-modeladorafeminina.webp'],
            description: 'Modele a sua silhueta e sinta-se mais confiante com a nossa cinta modeladora de alta compressão.',
            features: [
                '3 níveis de compressão ajustáveis',
                'Tecido respirável e hipoalergénico',
                'Ajuste anatómico perfeito',
                'Design invisível sob a roupa'
            ],
            benefits: [
                'Modela instantaneamente a silhueta',
                'Aumenta a autoconfiança e autoestima',
                'Proporciona suporte adequado para as costas',
                'Melhora significativamente a postura'
            ],
            specifications: {
                'Tamanhos': 'P, M, G, GG',
                'Material': 'Elastano e Poliamida',
                'Compressão': '3 níveis',
                'Garantia': 'Satisfação garantida'
            },
            testimonials: [
                {
                    text: "Uso diariamente e sinto-me muito mais confiante. A qualidade é excelente!",
                    author: "Ana L., Maputo"
                }
            ],
            urgency: 'Oferta limitada - 48h restantes!',
            badge: 'Popular'
        },
        'escova-facial': {
            name: 'Escova de Limpeza Facial',
            price: '799 MT',
            images: ['products/escova-delimpezafacial.webp'],
            description: 'Limpeza profunda e esfoliação suave para uma pele radiante e saudável todos os dias.',
            features: [
                'Cerdas ultra-macias e hipoalergénicas',
                'Resistente à água para uso no banho',
                'Design ergonómico para fácil manuseio',
                'Limpeza profunda dos poros'
            ],
            benefits: [
                'Pele mais limpa e radiante',
                'Remoção eficaz de impurezas e maquilhagem',
                'Pele mais suave e macia ao toque',
                'Aparência mais jovem e saudável'
            ],
            specifications: {
                'Material': 'Silicone médico',
                'Resistência': 'À prova de água',
                'Tamanho': '8cm x 6cm',
                'Garantia': '100% hipoalergénica'
            },
            badge: 'Novidade'
        },
        'mini-massageador': {
            name: 'Mini Massageador Portátil',
            price: '899 MT',
            originalPrice: '1.199 MT',
            discount: '25%',
            images: ['products/mini-massageadorportatil.webp'],
            description: 'Alívio instantâneo para dores musculares em qualquer lugar. Compacto e eficiente.',
            features: [
                'Bateria de longa duração (até 3 horas)',
                '4 velocidades diferentes de massagem',
                'Design compacto e portátil',
                'Carregamento via USB'
            ],
            benefits: [
                'Alívio imediato da dor muscular',
                'Relaxamento muscular profundo',
                'Uso conveniente em qualquer lugar',
                'Melhora a circulação sanguínea'
            ],
            specifications: {
                'Bateria': 'Lítio 2000mAh',
                'Velocidades': '4 níveis',
                'Peso': '300g',
                'Garantia': '1 ano'
            }
        },
        'removedor-cicatrizes': {
            name: 'Removedor de Cicatrizes',
            price: '1.599 MT',
            images: ['products/removedor-cicatrizes.webp'],
            description: 'Fórmula avançada para reduzir a aparência de cicatrizes e marcas na pele.',
            features: [
                'Resultados visíveis em 30 dias',
                'Ingredientes 100% naturais',
                'Fórmula clinicamente testada',
                'Seguro para todos os tipos de pele'
            ],
            benefits: [
                'Reduz significativamente a aparência de cicatrizes',
                'Melhora a textura e uniformidade da pele',
                'Restaura a confiança e autoestima',
                'Pele mais uniforme e suave'
            ],
            specifications: {
                'Volume': '30ml',
                'Ingredientes': '100% naturais',
                'Aplicação': '2x por dia',
                'Garantia': 'Clinicamente testado'
            },
            urgency: '12 pessoas a ver este produto',
            badge: 'Premium'
        },
        'slimming-herb': {
            name: 'Slimming Herb - Chá Emagrecedor',
            price: '699 MT',
            originalPrice: '899 MT',
            discount: '22%',
            images: ['products/slimming-herb.webp'],
            description: 'Chá natural para auxiliar na perda de peso e desintoxicação.',
            features: [
                'Acelera o metabolismo naturalmente',
                'Sem efeitos secundários',
                '100% ingredientes orgânicos',
                'Embalagem com 30 saquetas'
            ],
            benefits: [
                'Auxilia na perda de peso saudável',
                'Desintoxica o organismo',
                'Melhora o funcionamento do metabolismo',
                'Promove sensação de bem-estar'
            ],
            specifications: {
                'Conteúdo': '30 saquetas',
                'Ingredientes': '100% orgânicos',
                'Preparação': 'Água quente 3-5 min',
                'Garantia': 'Orgânico certificado'
            },
            badge: '100% Natural'
        },
        'top-academia': {
            name: 'Top de Academia Feminino',
            price: '999 MT',
            images: ['products/top-deacademia.webp'],
            description: 'Conforto e suporte para os seus treinos. Design moderno e tecido respirável.',
            features: [
                'Tecido anti-suor e respirável',
                'Suporte médio para atividades físicas',
                'Design moderno e elegante',
                'Secagem rápida'
            ],
            benefits: [
                'Conforto máximo durante o treino',
                'Suporte adequado sem apertar',
                'Estilo moderno e atrativo',
                'Liberdade completa de movimento'
            ],
            specifications: {
                'Tamanhos': 'P, M, G, GG',
                'Material': 'Poliéster e Elastano',
                'Suporte': 'Médio',
                'Garantia': 'Vários tamanhos disponíveis'
            }
        }
    };

    // Utilitários
    const Utils = {
        showNotification: function(message, type = 'success') {
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.innerHTML = `
                <div class="notification-content">
                    <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
                    <span>${message}</span>
                </div>
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(() => notification.classList.add('show'), 100);
            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => {
                    if (document.body.contains(notification)) {
                        document.body.removeChild(notification);
                    }
                }, 300);
            }, 5000);
        },

        formatWhatsAppMessage: function(productName, price) {
            return `🛒 *PEDIDO BIZORA*

📦 *Produto:* ${productName}
💰 *Preço:* ${price}

🚚 *Entrega:* Grátis em Maputo
💳 *Pagamento:* Na entrega

Olá! Gostaria de fazer este pedido. Podem confirmar a disponibilidade e prazo de entrega?

Obrigado! 😊`;
        }
    };

    // Gestão de Políticas de Privacidade - CORRIGIDO
    const PrivacyManager = {
        modal: null,
        
        init: function() {
            this.modal = document.getElementById('privacy-modal');
            this.setupEventListeners();
        },

        setupEventListeners: function() {
            if (!this.modal) return;

            // Fechar modal ao clicar no X ou fora do modal
            this.modal.addEventListener('click', (e) => {
                if (e.target === this.modal || e.target.classList.contains('close')) {
                    this.close();
                }
            });

            // Fechar modal com ESC
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && this.modal.style.display === 'block') {
                    this.close();
                }
            });
        },

        open: function() {
            if (!this.modal) return;
            
            this.modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
            this.modal.focus();
            
            // Verificar se há scroll no conteúdo
            const body = this.modal.querySelector('.privacy-modal-body');
            if (body && body.scrollHeight > body.clientHeight) {
                body.classList.add('has-scroll');
            }
        },

        close: function() {
            if (!this.modal) return;
            
            this.modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        },

        accept: function() {
            // Salvar preferência no localStorage
            localStorage.setItem('privacy-accepted', 'true');
            localStorage.setItem('privacy-accepted-date', new Date().toISOString());
            
            // Fechar modal
            this.close();
            
            // Mostrar notificação de sucesso
            Utils.showNotification('Políticas de privacidade aceites com sucesso!', 'success');
            
            // Ocultar aviso de cookies se estiver visível
            const cookieNotice = document.getElementById('cookie-notice');
            if (cookieNotice) {
                cookieNotice.style.display = 'none';
                localStorage.setItem('cookies-accepted', 'true');
            }
        }
    };

    // Gestão do Carrossel - CORRIGIDO
    const CarouselManager = {
        currentSlide: 0,
        totalSlides: 0,
        autoplayInterval: null,
        isInitialized: false,

        init: function() {
            this.carousel = document.getElementById('carousel');
            this.slides = document.querySelectorAll('.carousel-slide');
            this.indicators = document.querySelectorAll('.indicator');
            this.prevBtn = document.getElementById('carousel-prev');
            this.nextBtn = document.getElementById('carousel-next');

            if (!this.carousel || this.slides.length === 0) {
                console.warn('Carrossel não encontrado ou sem slides');
                return;
            }

            this.totalSlides = this.slides.length;
            this.setupEventListeners();
            this.preloadImages();
            this.updateCarousel();
            this.startAutoplay();
            this.isInitialized = true;
            
            console.log('Carrossel inicializado com', this.totalSlides, 'slides');
        },

        setupEventListeners: function() {
            // Botões de navegação
            if (this.prevBtn) {
                this.prevBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.previousSlide();
                });
            }
            if (this.nextBtn) {
                this.nextBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.nextSlide();
                });
            }

            // Indicadores
            this.indicators.forEach((indicator, index) => {
                indicator.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.goToSlide(index);
                });
            });

            // Pausar autoplay ao hover
            this.carousel.addEventListener('mouseenter', () => this.stopAutoplay());
            this.carousel.addEventListener('mouseleave', () => this.startAutoplay());

            // Suporte para touch/swipe
            this.setupTouchEvents();
        },

        setupTouchEvents: function() {
            let startX = 0;
            let endX = 0;

            this.carousel.addEventListener('touchstart', (e) => {
                startX = e.touches[0].clientX;
                this.stopAutoplay();
            });

            this.carousel.addEventListener('touchend', (e) => {
                endX = e.changedTouches[0].clientX;
                const diff = startX - endX;

                if (Math.abs(diff) > 50) {
                    if (diff > 0) {
                        this.nextSlide();
                    } else {
                        this.previousSlide();
                    }
                }
                this.startAutoplay();
            });
        },

        preloadImages: function() {
            this.slides.forEach(slide => {
                const img = slide.querySelector('img');
                if (img) {
                    // Garantir que a imagem seja carregada
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                    }
                    
                    // Adicionar fallback para imagens que não carregam
                    img.addEventListener('error', () => {
                        console.warn('Erro ao carregar imagem:', img.src);
                        img.style.display = 'none';
                    });
                }
            });
        },

        goToSlide: function(index) {
            if (index < 0 || index >= this.totalSlides) return;
            
            this.currentSlide = index;
            this.updateCarousel();
        },

        nextSlide: function() {
            this.currentSlide = (this.currentSlide + 1) % this.totalSlides;
            this.updateCarousel();
        },

        previousSlide: function() {
            this.currentSlide = (this.currentSlide - 1 + this.totalSlides) % this.totalSlides;
            this.updateCarousel();
        },

        updateCarousel: function() {
            if (!this.isInitialized) return;

            // Atualizar slides ativos
            this.slides.forEach((slide, index) => {
                slide.classList.toggle('active', index === this.currentSlide);
            });

            // Atualizar indicadores
            this.indicators.forEach((indicator, index) => {
                indicator.classList.toggle('active', index === this.currentSlide);
            });

            // Aplicar transformação CSS
            const translateX = -this.currentSlide * 100;
            this.carousel.style.transform = `translateX(${translateX}%)`;
        },

        startAutoplay: function() {
            this.stopAutoplay();
            this.autoplayInterval = setInterval(() => {
                this.nextSlide();
            }, CONFIG.carouselAutoplayDelay);
        },

        stopAutoplay: function() {
            if (this.autoplayInterval) {
                clearInterval(this.autoplayInterval);
                this.autoplayInterval = null;
            }
        }
    };

    // Gestão de Produtos e Modal
    const ProductManager = {
        init: function() {
            this.setupProductModal();
        },

        setupProductModal: function() {
            const modal = document.getElementById('product-modal');
            if (!modal) return;

            // Fechar modal ao clicar no X ou fora do modal
            modal.addEventListener('click', (e) => {
                if (e.target === modal || e.target.classList.contains('close')) {
                    this.closeModal();
                }
            });

            // Fechar modal com ESC
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && modal.style.display === 'block') {
                    this.closeModal();
                }
            });
        },

        openModal: function(productId) {
            const product = PRODUCTS_DATA[productId];
            if (!product) {
                console.warn('Produto não encontrado:', productId);
                return;
            }

            const modal = document.getElementById('product-modal');
            const modalBody = document.getElementById('modal-body');
            const modalTitle = document.getElementById('modal-product-title');

            if (!modal || !modalBody || !modalTitle) return;

            // Atualizar título do modal
            modalTitle.textContent = product.name;

            // Construir preço
            let priceHTML = `<div class="product-modal-price-current">${product.price}</div>`;
            let savingsHTML = '';
            
            if (product.originalPrice) {
                const savings = parseInt(product.originalPrice.replace(/[^\d]/g, '')) - parseInt(product.price.replace(/[^\d]/g, ''));
                priceHTML = `
                    <div class="product-modal-price-main">
                        <div class="product-modal-price-current">${product.price}</div>
                        <div class="product-modal-price-original">${product.originalPrice}</div>
                        <div class="product-modal-discount">-${product.discount}</div>
                    </div>
                `;
                savingsHTML = `<div class="product-modal-savings">Poupa ${savings} MT nesta compra!</div>`;
            }

            // Construir especificações
            let specificationsHTML = '';
            if (product.specifications) {
                specificationsHTML = `
                    <div class="product-modal-specifications">
                        <div class="product-modal-section-title">📋 Especificações Técnicas</div>
                        <div class="specifications-grid">
                            ${Object.entries(product.specifications).map(([key, value]) => 
                                `<div class="spec-item"><strong>${key}:</strong> ${value}</div>`
                            ).join('')}
                        </div>
                    </div>
                `;
            }

            // Construir depoimentos
            let testimonialsHTML = '';
            if (product.testimonials && product.testimonials.length > 0) {
                testimonialsHTML = `
                    <div class="product-testimonials">
                        <div class="product-modal-section-title">💬 Depoimentos de Clientes</div>
                        ${product.testimonials.map(testimonial => 
                            `<div class="testimonial-item">
                                "${testimonial.text}"
                                <div class="testimonial-author">- ${testimonial.author}</div>
                            </div>`
                        ).join('')}
                    </div>
                `;
            }

            // Construir urgência
            let urgencyHTML = '';
            if (product.urgency) {
                urgencyHTML = `
                    <div class="product-modal-urgency">
                        <i class="fas fa-fire"></i>
                        <span>${product.urgency}</span>
                    </div>
                `;
            }

            modalBody.innerHTML = `
                <div class="product-modal-content-grid">
                    <div class="product-modal-image-section">
                        <div class="product-modal-image-main">
                            <img src="${product.images[0]}" alt="${product.name}" loading="lazy">
                            ${product.badge ? `<div class="product-badge"><span class="badge-${product.badge.toLowerCase().replace(/\s+/g, '-').replace('%', '')}">${product.badge}</span></div>` : ''}
                        </div>
                    </div>
                    <div class="product-modal-info-section">
                        <div class="product-modal-title">${product.name}</div>
                        
                        <div class="product-modal-price-section">
                            ${priceHTML}
                            ${savingsHTML}
                        </div>
                        
                        ${urgencyHTML}
                        
                        <div class="product-modal-description">${product.description}</div>
                        
                        <div class="product-modal-features">
                            <div class="product-modal-section-title">⚡ Características Principais</div>
                            <ul class="product-modal-list">
                                ${product.features.slice(0, 5).map(feature => `<li>${feature}</li>`).join('')}
                            </ul>
                        </div>
                        
                        <div class="product-modal-benefits">
                            <div class="product-modal-section-title">🎯 Benefícios para Si</div>
                            <ul class="product-modal-list">
                                ${product.benefits.slice(0, 4).map(benefit => `<li>${benefit}</li>`).join('')}
                            </ul>
                        </div>
                        
                        ${specificationsHTML}
                        ${testimonialsHTML}
                        
                        <div class="product-modal-actions">
                            <button class="product-modal-whatsapp-btn" onclick="WhatsAppManager.quickOrder('${product.name}', '${product.price}')">
                                <i class="fab fa-whatsapp"></i> Comprar Agora via WhatsApp
                            </button>
                            <div class="product-modal-guarantee">
                                <i class="fas fa-shield-alt"></i>
                                <span>Pague na entrega • Entrega grátis em Maputo • Garantia de qualidade</span>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
            modal.focus();
        },

        closeModal: function() {
            const modal = document.getElementById('product-modal');
            if (modal) {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        }
    };

    // Gestão do WhatsApp
    const WhatsAppManager = {
        phoneNumber: '+258863181415',
        
        quickOrder: function(productName, price) {
            const message = Utils.formatWhatsAppMessage(productName, price);
            this.sendMessage(message);
        },

        sendMessage: function(message) {
            const encodedMessage = encodeURIComponent(message);
            const whatsappURL = `https://wa.me/${this.phoneNumber.replace('+', '')}?text=${encodedMessage}`;
            
            window.open(whatsappURL, '_blank');
            Utils.showNotification('Redirecionando para WhatsApp...', 'success');
        }
    };

    // Gestão de Cookies
    const CookieManager = {
        init: function() {
            const cookieNotice = document.getElementById('cookie-notice');
            const acceptBtn = document.getElementById('accept-cookies');

            if (!cookieNotice || !acceptBtn) return;

            // Verificar se já foi aceito
            if (localStorage.getItem('cookies-accepted') === 'true') {
                cookieNotice.style.display = 'none';
            }

            acceptBtn.addEventListener('click', () => {
                localStorage.setItem('cookies-accepted', 'true');
                cookieNotice.style.display = 'none';
                Utils.showNotification('Cookies aceites!', 'success');
            });
        }
    };

    // Funções Globais - CORRIGIDAS
    window.openPrivacyModal = function() {
        PrivacyManager.open();
    };

    window.closePrivacyModal = function() {
        PrivacyManager.close();
    };

    window.acceptPrivacyPolicy = function() {
        PrivacyManager.accept();
    };

    window.openProductModal = function(productId) {
        ProductManager.openModal(productId);
    };

    window.closeProductModal = function() {
        ProductManager.closeModal();
    };

    window.contactWhatsApp = function(productName, price) {
        WhatsAppManager.quickOrder(productName, price);
    };

    // Inicialização Principal
    document.addEventListener('DOMContentLoaded', function() {
        console.log('Inicializando Bizora Website...');

        // Inicializar todos os módulos
        PrivacyManager.init();
        CarouselManager.init();
        ProductManager.init();
        CookieManager.init();

        // Remover loading screen
        setTimeout(() => {
            const loadingScreen = document.getElementById('loading-screen');
            if (loadingScreen) {
                loadingScreen.style.opacity = '0';
                setTimeout(() => {
                    loadingScreen.style.display = 'none';
                }, 300);
            }
        }, 1000);

        // Adicionar estilos para notificações
        const notificationStyles = document.createElement('style');
        notificationStyles.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: white;
                border-radius: 8px;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
                padding: 1rem 1.5rem;
                z-index: 10000;
                transform: translateX(400px);
                opacity: 0;
                transition: all 0.3s ease;
                max-width: 350px;
            }
            
            .notification.show {
                transform: translateX(0);
                opacity: 1;
            }
            
            .notification-success {
                border-left: 4px solid #25D366;
            }
            
            .notification-error {
                border-left: 4px solid #e74c3c;
            }
            
            .notification-content {
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }
            
            .notification-success .fa-check-circle {
                color: #25D366;
            }
            
            .notification-error .fa-exclamation-circle {
                color: #e74c3c;
            }
            
            @media (max-width: 768px) {
                .notification {
                    right: 10px;
                    left: 10px;
                    max-width: none;
                    transform: translateY(-100px);
                }
                
                .notification.show {
                    transform: translateY(0);
                }
            }
        `;
        document.head.appendChild(notificationStyles);

        console.log('Bizora Website inicializado com sucesso!');
    });

})();

